'use strict';

app.controller('MainController', ['$scope',
    function MainController($scope) {
                $scope.message = " the message is :this is the main controller";
            }
     ]
); 