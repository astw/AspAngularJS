﻿'use strict';

app.controller('EditProfileController',
    function EditProfileController($scope) {
        $scope.user = {}; 
    }
);